export default async function handler(req, res) {
  return res.status(200).json({ message: "AI Studio API endpoint placeholder" });
}