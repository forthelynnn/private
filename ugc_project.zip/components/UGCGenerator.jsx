export default function UGCGenerator() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold">UGC Generator</h1>
      <p>UI Placeholder — silakan integrasikan komponen lengkap yang kamu minta sebelumnya.</p>
    </div>
  );
}